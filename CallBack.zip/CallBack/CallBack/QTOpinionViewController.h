//
//  QTOpinionViewController.h
//  ZhuRenWong
//
//  Created by wangfeng on 15-4-29.
//  Copyright (c) 2015年 qitian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QTOpinionViewController : UIViewController

@end
